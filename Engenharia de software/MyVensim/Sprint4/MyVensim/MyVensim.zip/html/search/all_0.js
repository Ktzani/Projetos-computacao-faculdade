var searchData=
[
  ['add_0',['add',['../classModel.html#a68c5ccf5dac67c0afcf8b374b7a71d94',1,'Model::add(Stock *sto)=0'],['../classModel.html#a0783386e3c2d18c0e9c457baa71325cb',1,'Model::add(Flow *flu)=0'],['../classModel.html#aec0f61f2b0775b70966925ab633705b3',1,'Model::add(Flow *flu, Stock *source, Stock *destiny)=0'],['../classMyModel.html#ac2c824525757e4a0dffdf6837251a917',1,'MyModel::add(Stock *sto)'],['../classMyModel.html#a82e15603d4fb1ab416733525d6eecf5a',1,'MyModel::add(Flow *flu)'],['../classMyModel.html#a4ea555ff1e3755c65534eb65ebe5547b',1,'MyModel::add(Flow *flu, Stock *source, Stock *destiny)']]]
];
