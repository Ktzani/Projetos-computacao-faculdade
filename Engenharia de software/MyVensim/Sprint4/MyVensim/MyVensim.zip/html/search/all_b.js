var searchData=
[
  ['remove_0',['remove',['../classModel.html#a412c4b98c018fe12835780e3bae17619',1,'Model::remove(string idStock)=0'],['../classModel.html#ad09bcd06190f17aedea0f8b141c2f2d3',1,'Model::remove(int idFlow)=0'],['../classMyModel.html#a295989186924e0a9534b2a7f6598cb27',1,'MyModel::remove(string idStock)'],['../classMyModel.html#a6319e265a06daef3d5fb47fe2b02c0e3',1,'MyModel::remove(int idFlow)']]],
  ['run_1',['run',['../classModel.html#a459b1a5044aa3ed60dd8d56b3f0596f6',1,'Model::run()'],['../classMyModel.html#a3eb49c5080c5d7179c4dbd62f6c53b9b',1,'MyModel::run()']]]
];
