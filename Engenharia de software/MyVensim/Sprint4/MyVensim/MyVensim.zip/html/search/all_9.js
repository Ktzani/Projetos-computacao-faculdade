var searchData=
[
  ['operator_3d_0',['operator=',['../classModel.html#a176616e4c1527dfacfda94c12541ab85',1,'Model::operator=()'],['../classStock.html#a22e2d16962fe18a7c98d7bd4dfc907f6',1,'Stock::operator=()']]]
];
