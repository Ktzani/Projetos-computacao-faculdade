var searchData=
[
  ['print_5fresults_0',['print_results',['../classModel.html#aa57fda99cf41d688d873da3ffe61f53e',1,'Model::print_results()'],['../classMyModel.html#a46afb6758dc9e0ba18c5e05523fceb53',1,'MyModel::print_results()']]]
];
