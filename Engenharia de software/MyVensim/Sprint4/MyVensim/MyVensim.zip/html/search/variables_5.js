var searchData=
[
  ['source_0',['source',['../classMyFlow.html#a04ef512025a57458f6fbc21199496685',1,'MyFlow']]],
  ['stocks_1',['stocks',['../classMyModel.html#a29cee559e7a211d22e06b14f5e3ec0c3',1,'MyModel']]]
];
