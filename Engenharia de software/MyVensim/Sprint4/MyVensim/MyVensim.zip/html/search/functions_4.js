var searchData=
[
  ['logistical_0',['logistical',['../minhasFuncoes_8cpp.html#a548b684388cc9276e1988c7463807152',1,'logistical(Stock *sto):&#160;minhasFuncoes.cpp'],['../minhasFuncoes_8h.html#a548b684388cc9276e1988c7463807152',1,'logistical(Stock *sto):&#160;minhasFuncoes.cpp']]],
  ['logisticalfuncionaltest_1',['logisticalFuncionalTest',['../funcional__tests_8cpp.html#ac9df0129352dd52de9dc7d0fc69660fe',1,'logisticalFuncionalTest():&#160;funcional_tests.cpp'],['../funcional__tests_8h.html#ac9df0129352dd52de9dc7d0fc69660fe',1,'logisticalFuncionalTest():&#160;funcional_tests.cpp']]]
];
