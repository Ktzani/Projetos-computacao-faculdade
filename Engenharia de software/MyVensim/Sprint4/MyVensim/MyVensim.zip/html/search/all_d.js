var searchData=
[
  ['value_0',['value',['../classMyStock.html#a173d7cb775ee9d36bdb7e71269b5059a',1,'MyStock']]],
  ['varbool_1',['varBool',['../classMyFlow.html#a4a83afdce4161f335c5e815e1f64ff52',1,'MyFlow']]]
];
