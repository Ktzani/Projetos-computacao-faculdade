var searchData=
[
  ['getcurrenttime_0',['getCurrentTime',['../classMyModel.html#aefcb874f04189e5f13fed5356c489e51',1,'MyModel::getCurrentTime()'],['../classModel.html#a5d0a069f36e0672898e4fb1155b10c1a',1,'Model::getCurrentTime()']]],
  ['getdestiny_1',['getDestiny',['../classFlow.html#afac31ee2bab218a01fddc2755b98f532',1,'Flow::getDestiny()'],['../classMyFlow.html#aafa15ab17c506456d5eab76491d24df1',1,'MyFlow::getDestiny()']]],
  ['getfinaltime_2',['getFinalTime',['../classModel.html#a26e822e664776243f1efe633a783e7a6',1,'Model::getFinalTime()'],['../classMyModel.html#a225563310cd7e2bf53f7bfd050132793',1,'MyModel::getFinalTime()']]],
  ['getflows_3',['getFlows',['../classModel.html#aa747630ddc45b81ae8963f2a0ee5e088',1,'Model::getFlows()'],['../classMyModel.html#a70fb532092958c1931f54d22944da4ed',1,'MyModel::getFlows()']]],
  ['getid_4',['getId',['../classMyStock.html#afe86f25da6fe35aa1effda405405b102',1,'MyStock::getId()'],['../classStock.html#af2c2d19420ea00eb5635f334dd0ca333',1,'Stock::getId()'],['../classMyModel.html#af05145cb4a08f100841c67c57a217dcd',1,'MyModel::getId()'],['../classModel.html#a822182451706920ac3251529fcb58c17',1,'Model::getId()'],['../classMyFlow.html#a2602aabebd7b11287098866fac13f9a8',1,'MyFlow::getId()'],['../classFlow.html#ac69358e6b5c35ef74a79d3164fff9024',1,'Flow::getId()']]],
  ['getinitialtime_5',['getInitialTime',['../classModel.html#a00c5d6f23a8c7e77bda0ac47aed34eb7',1,'Model::getInitialTime()'],['../classMyModel.html#a38617898b8b7bf2af63be14000d49ade',1,'MyModel::getInitialTime()']]],
  ['getinitialvalue_6',['getInitialValue',['../classStock.html#af7172b4baf769bba960b948931ff65ea',1,'Stock::getInitialValue()'],['../classMyStock.html#a4824830249ab9eb99cc6d93db701a027',1,'MyStock::getInitialValue()']]],
  ['getlastvalue_7',['getLastValue',['../classFlow.html#aa3671632b52cdf4b3e30ce5921f4dc74',1,'Flow::getLastValue()'],['../classMyFlow.html#a5747df0eafd30c967018e60759ec87ae',1,'MyFlow::getLastValue()']]],
  ['getsource_8',['getSource',['../classFlow.html#a41d7b22923bf21c10d94ef72291d103d',1,'Flow::getSource()'],['../classMyFlow.html#ac7f4b555f8036cf1ac2a6da789ac4366',1,'MyFlow::getSource()']]],
  ['getstocks_9',['getStocks',['../classModel.html#a03cebebf8ce355a2fb25c3cf0af77a98',1,'Model::getStocks()'],['../classMyModel.html#a8dbbc9e389c51229ce06f3b9611c2a4b',1,'MyModel::getStocks()']]],
  ['getvarbool_10',['getVarBool',['../classFlow.html#ae3dd3e476393b7f3d0a511091ae7ded3',1,'Flow::getVarBool()'],['../classMyFlow.html#a64708d42f7e49d99fb76fca68d5405fa',1,'MyFlow::getVarBool()']]]
];
