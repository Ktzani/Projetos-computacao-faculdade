#ifndef MINHASFUNCOES
#define MINHASFUNCOES
#include "stock_impl.h"

double exponencial(Stock*);

double logistical(Stock* sto);

#endif