#ifndef UNIT_TESTS
#define UNIT_TESTS
        void unit_exponencial( void );
        void unit_logistical( void );
        void run_unit_tests_globals( void );
#endif