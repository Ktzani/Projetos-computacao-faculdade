var searchData=
[
  ['value_0',['value',['../classStock.html#a4f626dedc98077b3e11faa9085c47ced',1,'Stock']]],
  ['varbool_1',['varBool',['../classFlow.html#a33ada1c3cdbd3deef9a643f77e90e6ad',1,'Flow']]]
];
