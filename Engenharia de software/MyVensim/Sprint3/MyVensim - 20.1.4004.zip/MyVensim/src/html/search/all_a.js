var searchData=
[
  ['remove_0',['remove',['../classModel.html#a2488378bf948080c93980f91ea8b6c3e',1,'Model::remove(string idStock)'],['../classModel.html#a11d117ba6607c10e8fe2a438fdab703d',1,'Model::remove(int idFlow)']]],
  ['run_1',['run',['../classModel.html#aeb77d4bd1d247721d0c521ae95ceb8e6',1,'Model']]]
];
