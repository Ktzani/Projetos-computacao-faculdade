var searchData=
[
  ['logistical_0',['logistical',['../main_8cpp.html#a548b684388cc9276e1988c7463807152',1,'main.cpp']]]
];
