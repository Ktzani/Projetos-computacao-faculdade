var searchData=
[
  ['add_0',['add',['../classModel.html#a16367ad8f113252d4a97bb97e1eedc35',1,'Model::add(Stock *sto)'],['../classModel.html#a35a2f86bfb885b58afa0e6ecf03f15ae',1,'Model::add(Flow *flu)'],['../classModel.html#a2cbac8517a85e5330adb79fad94c7806',1,'Model::add(Flow *flu, Stock *source, Stock *destiny)']]]
];
