var searchData=
[
  ['currenttime_0',['currentTime',['../classModel.html#aaef80a6b6e88ec2ccf8799e5863c7347',1,'Model']]]
];
