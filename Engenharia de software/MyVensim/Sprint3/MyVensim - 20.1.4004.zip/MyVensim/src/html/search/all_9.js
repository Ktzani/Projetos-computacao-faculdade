var searchData=
[
  ['print_5fresults_0',['print_results',['../classModel.html#ac818d90a3939f0c2a27a292d1473da5f',1,'Model']]]
];
