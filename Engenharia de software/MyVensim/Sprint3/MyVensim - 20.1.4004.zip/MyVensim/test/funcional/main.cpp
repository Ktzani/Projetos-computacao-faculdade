#ifndef  MAIN_FUNCIONAL_TESTS
#define MAIN_FUNCIONA_TESTS

#include "funcional_tests.h"

int main(){

    exponentialFuncionalTest();

    logisticalFuncionalTest();

    complexFuncionalTest();

    return true;

}

#endif