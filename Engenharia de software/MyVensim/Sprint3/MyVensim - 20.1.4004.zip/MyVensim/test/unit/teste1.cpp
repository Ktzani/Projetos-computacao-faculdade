#include <assert.h>

bool testConnection(){
    Flow f();
    assert( f.connection(source, destiny) == );
}