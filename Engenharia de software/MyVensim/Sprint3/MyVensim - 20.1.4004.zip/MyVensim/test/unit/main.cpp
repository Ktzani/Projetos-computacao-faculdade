#include <iostream>
#include <string>
#include "../src/mySim.h"

using namespace std;

int main (){

    //Nível de teste

    //Chamo o cenario de teste1
    //Chamo o cenario de teste2 e por assim vai

    //Exemplo
    printf("Inicio teste\n\n");

    testConnection ();

    printf("\nFim teste\n")
}