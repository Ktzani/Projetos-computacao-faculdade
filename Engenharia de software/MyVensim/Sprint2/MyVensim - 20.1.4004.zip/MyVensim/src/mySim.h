#ifndef MYSIM_H
#define MYSIM_H
#include <string.h>
#include <iostream>

using namespace std;





#endif